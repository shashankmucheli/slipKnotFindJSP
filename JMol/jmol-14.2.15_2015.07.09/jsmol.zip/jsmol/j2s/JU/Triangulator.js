Clazz.declarePackage ("JU");
Clazz.declareInterface (JU, "Triangulator");
